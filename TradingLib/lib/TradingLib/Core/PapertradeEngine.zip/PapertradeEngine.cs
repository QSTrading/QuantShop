﻿using System;
using System.Collections.Generic;
using TradeLink.API;
using TradeLink.Common;

namespace TradingLib.Core
{
    /// <summary>
    /// route your orders through this component to paper trade with a live data feed
    /// 模拟交易
    /// </summary>
    public class PapertradeEngine
    {
        IdTracker _idt;
        public PapertradeEngine() : this(new IdTracker()) { }
        public PapertradeEngine(IdTracker idt)
        {
            _idt = idt;
        }
        bool _usebidask = true;
        /// <summary>
        /// whether to use bid ask for fills, otherwise last is used.
        /// </summary>
        public bool UseBidAskFills { get { return _usebidask; } set { _usebidask = value; } }
        /// <summary>
        /// fill acknowledged, order filled.
        /// </summary>
        public event FillDelegate GotFillEvent;
        /// <summary>
        /// order acknowledgement, order placed.
        /// </summary>
        public event OrderDelegate GotOrderEvent;
        /// <summary>
        /// cancel acknowledgement, order is canceled
        /// </summary>
        public event LongDelegate GotCancelEvent;
        /// <summary>
        /// copy of the cancel request
        /// </summary>
        public event LongDelegate SendCancelEvent;

        /// <summary>
        /// debug messages
        /// </summary>
        public event DebugDelegate SendDebugEvent;

        TickTracker _kt = new TickTracker();

        public const string DEFAULTBOOK = "DEFAULT";
        protected Account DEFAULT = new Account(DEFAULTBOOK, "Defacto account when account not provided");
        protected Dictionary<Account, List<Order>> MasterOrders = new Dictionary<Account, List<Order>>();
        protected Dictionary<string, List<Trade>> MasterTrades = new Dictionary<string, List<Trade>>();


        /// <summary>
        /// 产生新的tick用于引擎Fill Order
        /// </summary>
        /// <param name="k"></param>
        public void newTick(Tick k)
        {
            _kt.addindex(k.symbol);
            _kt.newTick(k);
            process();
        }

        void debug(string msg)
        {
            if (SendDebugEvent != null)
                SendDebugEvent(msg);
        }

        Queue<Order> aq = new Queue<Order>(100);
        Queue<long> can = new Queue<long>(100);

        /// <summary>
        /// gets currently queued orders
        /// </summary>
        public Order[] QueuedOrders { get { lock (aq) { return aq.ToArray(); } } }

        /// <summary>
        /// gets count of queued cancels
        /// </summary>
        public int QueuedCancelCount { get { lock (can) { return can.Count; } } }

        

        /// <summary>
        /// send paper trade orders
        /// </summary>
        /// <param name="o"></param>
        public void sendorder(Order o)
        {
            if (o.id == 0)
                o.id = _idt.AssignId;
            lock (aq)
            {
                debug("PTT Server queueing order: " + o.ToString());
                aq.Enqueue(o);
            }
            // ack the order
            if (GotOrderEvent != null)
                GotOrderEvent(o);
            //有order进入时候我们不需要进行处理,order的fill均由tick引发
            //process();
        }

        /*
        List<string> hasopened = new List<string>();
        /// <summary>
        /// Executes any open orders allowed by the specified tick.
        /// 通过行情触发stop单或者其他预埋单
        /// </summary>
        /// <param name="tick">The tick.</param>
        /// <returns>the number of orders executed using the tick.</returns>
        public int Execute(Tick tick)
        {
            bool _usebidaskfill = _usebidask;
            //if (_pendorders == 0) return 0;
            if (!tick.isTrade && !_usebidaskfill) return 0;
            int filledorders = 0;
            Account[] accts = new Account[MasterOrders.Count];
            MasterOrders.Keys.CopyTo(accts, 0);
            for (int idx = 0; idx < accts.Length; idx++)
            { // go through each account
                Account a = accts[idx];
                // if account has requested no executions, skip it
                if (!a.Execute) continue;
                // make sure we have a record for this account
                if (!MasterTrades.ContainsKey(a.ID))
                    MasterTrades.Add(a.ID, new List<Trade>());
                // track orders being removed and trades that need notification
                List<int> notifytrade = new List<int>();
                List<int> remove = new List<int>();
                // go through each order in the account
                for (int i = 0; i < MasterOrders[a].Count; i++)
                {
                    Order o = MasterOrders[a][i];
                    if (tick.symbol != o.symbol) continue; //make sure tick is for the right stock
                    bool filled = false;
                    if (o.TIF == "OPG")
                    {
                        // if it's already opened, we missed our shot
                        if (hasopened.Contains(o.symbol)) continue;
                        // otherwise make sure it's really the opening
                        if (((o.symbol.Length < 4) && (tick.ex.Contains("NYS"))) ||
                            (o.symbol.Length > 3))
                        {
                            // it's the opening tick, so fill it as an opg
                            filled = o.Fill(tick, _usebidaskfill, true);
                            // mark this symbol as already being open
                            hasopened.Add(tick.symbol);
                        }

                    }
                    else // otherwise fill order normally
                        filled = o.Fill(tick, _usebidaskfill, false); // fill our trade
                    if (filled)
                    {
                        // remove filled size from size available in trade
                        tick.size -= o.UnsignedSize;
                        // get copy of trade for recording
                        Trade trade = new TradeImpl((Trade)o);
                        // if trade represents entire requested order, mark order for removal
                        if (trade.UnsignedSize == o.UnsignedSize)
                            remove.Add(i);
                        else // otherwise reflect order's remaining size
                            o.size = (o.UnsignedSize - trade.UnsignedSize) * (o.side ? 1 : -1);
                        // record trade
                        MasterTrades[a.ID].Add(trade);
                        // mark it for notification
                        notifytrade.Add(MasterTrades[a.ID].Count - 1);
                        // count the trade
                        filledorders++;
                    }
                }
                int rmcount = remove.Count;
                // remove the filled orders
                for (int i = remove.Count - 1; i >= 0; i--)
                    MasterOrders[a].RemoveAt(remove[i]);
                // unmark filled orders as pending
                //_pendorders -= rmcount;
                //if (_pendorders < 0) _pendorders = 0;
                // notify subscribers of trade
                if ((GotFill != null) && a.Notify)
                    for (int tradeidx = 0; tradeidx < notifytrade.Count; tradeidx++)
                        GotFill(MasterTrades[a.ID][notifytrade[tradeidx]]);

            }
            return filledorders;
        }*/

        void process()
        {
            Order[] orders;
            long[] cancels;
            lock (aq)
            {
                // get copy of current orders
                 orders = aq.ToArray();
                 aq.Clear();

                //get current cancels
                 cancels = can.ToArray();
                 can.Clear();
            }
            // get ready for unfilled orders
            List<Order> unfilled = new List<Order>();
            // try to fill every order
            for (int i = 0; i < orders.Length; i++)
            {
                debug("we have orders now we deal with them");
                // get order
                Order o = orders[i];
                // check for a cancel, if so remove cancel, acknowledge and continue
                int cidx = gotcancel(o.id, cancels);
                if (cidx >= 0)
                {
                    debug("PTT Server canceling: " + o.id);
                    cancels[cidx] = 0;
                    if (GotCancelEvent != null)
                        GotCancelEvent(o.id);
                    continue;
                }

                // try to fill it
                //OrderImpl oi = o as OrderImpl;
                //oi.SendDebugEvent+=new DebugDelegate(debug);
                //debug("order size:" + o.size.ToString());
                bool filled = o.Fill(_kt[o.symbol], UseBidAskFills, false);
                //debug("order size:" + o.size.ToString());
                // if it doesn't fill, add it back and continue
                debug("we check if filed:"+filled.ToString());
                if (!filled)
                {
                    debug("we add it back to unfilled");
                    unfilled.Add(o);
                    continue;
                }
                
                // check for partial fill
                Trade fill = (Trade)o;
                debug("PTT Server filled: " + fill.ToString());
                bool partial = fill.UnsignedSize != o.UnsignedSize;
                debug("@@Filled Filled Size:"+fill.UnsignedSize.ToString()+"  Order Size:"+o.UnsignedSize.ToString());
                // if partial fill, update original order and add it back
                if (partial)
                {
                    
                    o.size = (o.UnsignedSize - fill.UnsignedSize) * (o.side ? 1 : -1);
                    debug("add remained order into unfilled:" + o.size.ToString());
                    unfilled.Add(o);
                    debug("***unfilled order number:" + unfilled.Count.ToString());
                }
                // acknowledge the fill
                if (GotFillEvent != null)
                    GotFillEvent(fill);
            }
            debug("***####unfilled order number:" + unfilled.Count.ToString());
            lock (aq)
            {
                debug("look here:");
                debug("****unfilled order number:" + unfilled.Count.ToString());
                // add orders back
                for (int i = 0; i < unfilled.Count; i++)
                {
                    aq.Enqueue(unfilled[i]);
                    debug("we are add unfilled order into queue");
                }
                // add cancels back
                for (int i = 0; i < cancels.Length; i++)
                    if (cancels[i] != 0)
                        can.Enqueue(cancels[i]);
            }
        }

        int gotcancel(long id, long[] ids)
        {
            if (id == 0) return -1;
            for (int i = 0; i < ids.Length; i++)
                if (id == ids[i]) return i;
            return -1;
        }

        /// <summary>
        /// cancel papertrade orders
        /// </summary>
        /// <param name="id"></param>
        public void sendcancel(long id)
        {
            if (id == 0) return;
            lock (aq)
            {
                can.Enqueue(id);
                debug(" PTT queueing cancel: " + id);
            }
            if (SendCancelEvent != null)
                SendCancelEvent(id);
            process();
        }
    }
}
